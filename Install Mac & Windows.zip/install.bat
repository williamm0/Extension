@echo off
setlocal
title jx Tools Installer

echo.
echo   jx Tools — Windows Installer
echo.
echo   Which version do you want?
echo     s  Latest stable (default)
echo     p  Latest pre-release
echo.
set /p CHOICE="  Choice [s/p]: "

if /i "%CHOICE%"=="p" (
    powershell -NoProfile -ExecutionPolicy Bypass -Command ^
        "$ErrorActionPreference = 'Stop';" ^
        "try {" ^
        "  $data = Invoke-RestMethod -Uri 'https://api.github.com/repos/williamm0/Extension/releases' -Headers @{ 'User-Agent' = 'jx-installer' };" ^
        "  $pre = $data | Where-Object { $_.prerelease -eq $true } | Select-Object -First 1;" ^
        "  if (-not $pre) { Write-Host '  No pre-release found, using stable.' -ForegroundColor Yellow; exit 2 };" ^
        "  $url = ($pre.assets | Where-Object { $_.name -like '*.zip' } | Select-Object -ExpandProperty browser_download_url -First 1);" ^
        "  if (-not $url) { $url = $pre.zipball_url };" ^
        "  [System.IO.File]::WriteAllText([System.IO.Path]::Combine($env:TEMP, 'jx_url.txt'), $url);" ^
        "  exit 0;" ^
        "} catch { exit 1 }"
    if %errorlevel% equ 0 (
        set /p ASSET_URL=<"%TEMP%\jx_url.txt"
        del "%TEMP%\jx_url.txt" 2>nul
        goto :download
    )
    echo   Falling back to latest stable.
)

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
    "$rel = Invoke-RestMethod -Uri 'https://api.github.com/repos/williamm0/Extension/releases/latest' -Headers @{ 'User-Agent' = 'jx-installer' };" ^
    "$url = ($rel.assets | Where-Object { $_.name -like '*.zip' } | Select-Object -ExpandProperty browser_download_url -First 1);" ^
    "if (-not $url) { $url = $rel.zipball_url };" ^
    "[System.IO.File]::WriteAllText([System.IO.Path]::Combine($env:TEMP, 'jx_url.txt'), $url)"
set /p ASSET_URL=<"%TEMP%\jx_url.txt"
del "%TEMP%\jx_url.txt" 2>nul

:download
set "BUNDLE=com.jx.tools"
set "CEP=%APPDATA%\Adobe\CEP\extensions"
set "DEST=%CEP%\%BUNDLE%"

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
    "$ErrorActionPreference = 'Stop';" ^
    "try {" ^
    "  Write-Host '  Downloading...' -ForegroundColor Cyan;" ^
    "  $zipPath = Join-Path $env:TEMP 'jx_dl.zip';" ^
    "  Invoke-WebRequest -Uri '%ASSET_URL%' -OutFile $zipPath -UseBasicParsing;" ^
    "  Write-Host '  Unpacking...' -ForegroundColor Cyan;" ^
    "  $extract = Join-Path $env:TEMP ('jx_xtract_' + (Get-Date -UFormat '%%s'));" ^
    "  Expand-Archive -Path $zipPath -DestinationPath $extract -Force;" ^
    "  $csxs = Get-ChildItem -Path $extract -Filter 'CSXS' -Recurse -Directory | Select-Object -First 1;" ^
    "  if (-not $csxs) { throw 'No valid extension found in download.' };" ^
    "  $src = $csxs.Parent.FullName;" ^
    "  Write-Host '  Installing...' -ForegroundColor Cyan;" ^
    "  if (Test-Path '%DEST%') { Remove-Item '%DEST%' -Recurse -Force };" ^
    "  New-Item -ItemType Directory -Path '%DEST%' -Force | Out-Null;" ^
    "  Copy-Item -Path \"$src\*\" -Destination '%DEST%' -Recurse -Force;" ^
    "  Get-Item '%DEST%\install.*' -ErrorAction SilentlyContinue | Remove-Item -Force;" ^
    "  Remove-Item $zipPath -Force;" ^
    "  Write-Host '  Done!' -ForegroundColor Green;" ^
    "} catch {" ^
    "  Write-Host ('  ERROR: ' + $_.Exception.Message) -ForegroundColor Red;" ^
    "  exit 1;" ^
    "}"

if %errorlevel% neq 0 (
    echo.
    echo   Installation failed.
    pause
    exit /b 1
)

echo   Enabling Adobe Developer Mode...
for %%v in (9 10 11 12 13 14) do (
    reg add "HKCU\Software\Adobe\CSXS.%%v" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
)

echo.
echo   All set! Restart After Effects and check Window ^> Extensions.
echo.
pause
endlocal
