#!/bin/bash

BUNDLE_ID="com.jx.tools"
CEP_DIR="$HOME/Library/Application Support/Adobe/CEP/extensions"
DEST="$CEP_DIR/$BUNDLE_ID"
TMP_DIR="/tmp/jx_mac_install_$(date +%s)"

echo ""
echo "  jx Tools — macOS Installer"
echo ""
echo "  Which version do you want?"
echo "    s  Latest stable (default)"
echo "    p  Latest pre-release"
echo ""
read -rp "  Choice [s/p]: " CHOICE

if [ "$CHOICE" = "p" ] || [ "$CHOICE" = "P" ]; then
    echo "  Checking for pre-releases..."
    ASSET_URL=$(curl -sL "https://api.github.com/repos/williamm0/Extension/releases" | python3 -c "
import sys, json
try:
    data = json.load(sys.stdin)
    pre = [r for r in data if r.get('prerelease')]
    if not pre:
        sys.exit(1)
    r = pre[0]
    assets = r.get('assets', [])
    if assets:
        print(assets[0]['browser_download_url'])
    else:
        print(r.get('zipball_url', ''))
except Exception:
    sys.exit(1)
" 2>/dev/null)
    if [ -z "$ASSET_URL" ]; then
        echo "  No pre-release found. Falling back to latest stable."
        CHOICE="s"
    fi
fi

if [ "$CHOICE" != "p" ] && [ "$CHOICE" != "P" ]; then
    echo "  Connecting to GitHub..."
    API_URL="https://api.github.com/repos/williamm0/Extension/releases/latest"
    ASSET_URL=$(curl -sL "$API_URL" | grep "browser_download_url" | grep -i "\.zip" | cut -d '"' -f 4 | head -n 1)
    if [ -z "$ASSET_URL" ]; then
        ASSET_URL=$(curl -sL "$API_URL" | grep "zipball_url" | cut -d '"' -f 4 | head -n 1)
    fi
fi

if [ -z "$ASSET_URL" ]; then
    echo "  ERROR: Could not find a release to download."
    exit 1
fi

echo "  Unlocking Adobe permissions..."
for v in 9 10 11 12 13 14; do
    defaults write com.adobe.CSXS.$v PlayerDebugMode 1 2>/dev/null
done
killall -u "$(whoami)" cfprefsd 2>/dev/null

echo "  Downloading..."
mkdir -p "$TMP_DIR"
curl -L -s "$ASSET_URL" -o "$TMP_DIR/release.zip"

echo "  Unpacking..."
unzip -q "$TMP_DIR/release.zip" -d "$TMP_DIR/extracted"

CSXS_DIR=$(find "$TMP_DIR/extracted" -type d -name "CSXS" | head -n 1)
if [ -z "$CSXS_DIR" ]; then
    echo "  ERROR: No valid extension found in the download."
    rm -rf "$TMP_DIR"
    exit 1
fi

SRC_PATH=$(dirname "$CSXS_DIR")

echo "  Installing..."
mkdir -p "$CEP_DIR"
rm -rf "$DEST"
cp -R "$SRC_PATH/" "$DEST"

rm -f "$DEST/install.bat" "$DEST/install.command" 2>/dev/null
xattr -rd com.apple.quarantine "$DEST" 2>/dev/null
rm -rf "$TMP_DIR"

echo ""
echo "  Done! Restart After Effects and check Window > Extensions."
echo ""
read -rp "Press [Enter] to exit..."
